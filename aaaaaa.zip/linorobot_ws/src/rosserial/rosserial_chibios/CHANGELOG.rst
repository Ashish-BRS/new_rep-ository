^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosserial_chibios
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.2 (2021-04-02)
------------------

0.9.1 (2020-09-09)
------------------

0.9.0 (2020-08-25)
------------------
* Added support for ChibiOS clients (`#493 <https://github.com/ros-drivers/rosserial/issues/493>`_)
* Contributors: Hermann von Kleist
